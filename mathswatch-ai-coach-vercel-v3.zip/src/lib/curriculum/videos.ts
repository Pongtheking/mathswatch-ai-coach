import { SKILLS } from "@/lib/curriculum/data";

/** 1st Class Maths walkthroughs — only visual/procedural skills. */

export type SkillVideo = {
  href: string;
  query: string;
};

const CHANNEL_SEARCH = "https://www.youtube.com/@1stClassMaths/search?query=";

const confirmed = (id: string): SkillVideo => ({
  href: `https://www.youtube.com/watch?v=${id}`,
  query: id,
});

const search = (query: string): SkillVideo => ({
  href: CHANNEL_SEARCH + encodeURIComponent(query),
  query,
});

/**
 * Direct watch URLs only when the 1st Class Maths video is confirmed.
 * Everything else is a channel search so we never link the wrong clip.
 */
export const SKILL_VIDEOS: Record<string, SkillVideo> = {
  "geo.circle-theorems": confirmed("dBIlCD_JF9Q"),
  "geo.trig-right": confirmed("lRDHqGqRNwg"),
  "geo.vectors": confirmed("PxDfkq3FMaw"),
  "pro.tree-diagrams": confirmed("Z5BX-LbG7mI"),
  "gra.transformations": confirmed("ctVr9NpSiL4"),

  "geo.transformations": search("Enlargements translations rotations"),
  "geo.constructions": search("Constructions"),
  "geo.loci": search("Loci"),
  "geo.similarity": search("Similar shapes"),
  "geo.similar-area-volume": search("Similar areas volumes"),
  "geo.bearings": search("Bearings"),
  "geo.pythagoras": search("Pythagoras"),
  "geo.trig-sine-cosine": search("Sine rule cosine rule"),
  "geo.3d-trig": search("3D trigonometry Pythagoras"),
  "geo.exact-trig": search("Exact trig values"),
  "geo.sectors": search("Sectors arcs"),
  "geo.plans-elevations": search("Plans and elevations"),
  "geo.triangle-area-trig": search("Area of a triangle sine"),

  "pro.venn": search("Venn diagrams"),
  "pro.conditional": search("Conditional probability"),
  "pro.frequency-trees": search("Frequency trees"),

  "gra.trig-graphs": search("Trig graphs"),
  "gra.quadratic": search("Quadratic graphs"),
  "gra.velocity-time": search("Speed time graphs"),
  "gra.linear": search("Straight line graphs"),

  "sta.histograms": search("Histograms"),
  "sta.box-plots": search("Box plots"),
  "sta.cumulative-frequency": search("Cumulative frequency"),
  "sta.scatter": search("Scatter graphs"),
};

export function videoForSkill(skillId: string | undefined | null): SkillVideo | null {
  if (!skillId) return null;
  return SKILL_VIDEOS[skillId] ?? null;
}

const NAME_TO_ID = Object.fromEntries(SKILLS.map((s) => [s.name, s.id]));

export function videoForSkillName(name: string | undefined | null): SkillVideo | null {
  if (!name) return null;
  return videoForSkill(NAME_TO_ID[name]);
}

export function firstVideoForSkills(skillIds: Array<string | undefined | null>): SkillVideo | null {
  for (const id of skillIds) {
    const v = videoForSkill(id);
    if (v) return v;
  }
  return null;
}
