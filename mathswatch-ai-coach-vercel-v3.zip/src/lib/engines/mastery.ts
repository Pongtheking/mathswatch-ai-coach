import { clamp } from "@/lib/utils";

export type MasteryState = {
  skillId: string;
  score: number | null;
  attempts: number;
  correctCount: number;
  recentAccuracy: number;
  confidence: number;
  mistakeFrequency: number;
  retentionScore: number;
  lastPracticedAt: string | null;
  nextReviewAt: string | null;
  intervalDays: number;
  easiness: number;
};

export type AttemptEvidence = {
  skillId: string;
  correct: boolean;
  difficulty: number;
  timeMs: number;
  mistakeCount: number;
  now?: Date;
};

const DEFAULT_INTERVALS = [0, 2, 7, 21, 45];

export function emptyMastery(skillId: string): MasteryState {
  return {
    skillId,
    score: null,
    attempts: 0,
    correctCount: 0,
    recentAccuracy: 0,
    confidence: 0,
    mistakeFrequency: 0,
    retentionScore: 100,
    lastPracticedAt: null,
    nextReviewAt: null,
    intervalDays: 0,
    easiness: 2.5,
  };
}

/**
 * Real mastery update. Recent evidence outweighs old results, jumps are
 * capped, and unused skills slowly decay. Raw attempt rows remain the source
 * of truth; this only produces the next snapshot.
 */
export function applyAttempt(state: MasteryState, ev: AttemptEvidence): MasteryState {
  const now = ev.now ?? new Date();
  const n = state.attempts + 1;
  const prev = state.score ?? (ev.correct ? 35 : 20);
  const stepSize = 0.22 + 0.38 / Math.sqrt(n);

  let delta: number;
  if (ev.correct) {
    const headroom = 1 - prev / 110;
    const hardness = 0.7 + ev.difficulty / 18;
    delta = 10 * hardness * headroom;
    if (ev.mistakeCount > 0) delta *= 0.55;
    if (ev.timeMs > 0 && ev.timeMs < 20_000 && ev.difficulty >= 6) delta *= 1.08;
  } else {
    const easyFail = ev.difficulty <= 4 ? 1.25 : 1;
    delta = -(7 + (10 - ev.difficulty) * 0.7) * easyFail;
    if (ev.mistakeCount >= 2) delta -= 2;
  }
  delta = clamp(delta, -14, 12);

  const score = clamp(prev + delta * stepSize * 4.2, 0, 100);
  const recentAccuracy = state.recentAccuracy * 0.68 + (ev.correct ? 100 : 0) * 0.32;
  const mistakeFrequency =
    state.mistakeFrequency * 0.75 + Math.min(3, ev.mistakeCount) * (100 / 3) * 0.25;
  const confidence = clamp(
    Math.log2(1 + n) * 18 + (recentAccuracy - 50) * 0.25,
    0,
    100,
  );

  const spaced = nextSpaced(state, ev.correct, now);

  return {
    ...state,
    score,
    attempts: n,
    correctCount: state.correctCount + (ev.correct ? 1 : 0),
    recentAccuracy: clamp(recentAccuracy, 0, 100),
    confidence,
    mistakeFrequency: clamp(mistakeFrequency, 0, 100),
    retentionScore: 100,
    lastPracticedAt: now.toISOString(),
    nextReviewAt: spaced.nextReviewAt,
    intervalDays: spaced.intervalDays,
    easiness: spaced.easiness,
  };
}

export function decayMastery(state: MasteryState, now = new Date()): MasteryState {
  if (!state.lastPracticedAt || state.score === null) return state;
  const last = new Date(state.lastPracticedAt);
  const days = (now.getTime() - last.getTime()) / 86_400_000;
  const due = state.intervalDays || 7;
  if (days <= due + 2) {
    return { ...state, retentionScore: clamp(100 - Math.max(0, days - due) * 4, 40, 100) };
  }
  const overdueWeeks = (days - due) / 7;
  const decayed = state.score * Math.pow(0.97, overdueWeeks);
  const retention = clamp(100 - overdueWeeks * 12, 25, 100);
  return {
    ...state,
    score: clamp(decayed, 0, 100),
    retentionScore: retention,
  };
}

function nextSpaced(state: MasteryState, correct: boolean, now: Date) {
  let easiness = state.easiness;
  let interval = state.intervalDays;
  if (correct) {
    easiness = clamp(easiness + 0.08, 1.3, 2.8);
    if (interval <= 0) interval = DEFAULT_INTERVALS[1];
    else if (interval < 7) interval = DEFAULT_INTERVALS[2];
    else interval = Math.round(interval * easiness);
  } else {
    easiness = clamp(easiness - 0.22, 1.3, 2.8);
    interval = 1;
  }
  interval = clamp(interval, 1, 60);
  const next = new Date(now.getTime() + interval * 86_400_000);
  return { intervalDays: interval, easiness, nextReviewAt: next.toISOString() };
}

/** Map 0–100 mastery of a skill set into an internal 1.0–9.0 learning estimate. */
export function estimateGrade(
  skills: Array<{
    score: number | null;
    relevance: number;
    examFreq: number;
    gradeMin: number;
    gradeMax: number;
    attempts: number;
  }>,
): { estimate: number | null; assessedSkills: number } {
  const assessed = skills.filter((s) => s.score !== null && s.attempts > 0);
  if (assessed.length < 3) return { estimate: null, assessedSkills: assessed.length };

  let num = 0;
  let den = 0;
  for (const s of assessed) {
    const w = s.relevance * 0.55 + s.examFreq * 0.3 + (s.gradeMax >= 8 ? 4 : 1);
    const grade = 1 + ((s.score ?? 0) / 100) * 8;
    const ceiling = s.gradeMax + 0.2;
    const floored = Math.min(grade, ceiling);
    num += floored * w;
    den += w;
  }
  const raw = num / den;
  // Grade 9 needs strength on higher-tier skills, not just foundation fluency.
  const higher = assessed.filter((s) => s.gradeMax >= 8);
  let estimate = raw;
  if (higher.length >= 2) {
    const higherAvg =
      higher.reduce((a, s) => a + (s.score ?? 0), 0) / higher.length;
    if (higherAvg < 70) estimate = Math.min(estimate, 7.6);
    if (higherAvg < 55) estimate = Math.min(estimate, 6.6);
  }
  return { estimate: Math.round(clamp(estimate, 1, 9) * 10) / 10, assessedSkills: assessed.length };
}
