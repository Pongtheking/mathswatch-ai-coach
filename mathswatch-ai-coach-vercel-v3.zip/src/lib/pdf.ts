export type PageImage = {
  mime: "image/jpeg";
  base64: string;
  page: number;
  width: number;
  height: number;
};

const MAX_PAGES = 14;
const MAX_EDGE = 1280;
const TARGET_B64 = 260_000;

function looksLikeMarkScheme(name: string, text: string): boolean {
  const n = name.toLowerCase();
  if (/(mark\s*scheme|\bms\b|markscheme|scheme|answers)/i.test(n) && !/script|completed|worked/i.test(n)) {
    return true;
  }
  const hits = (text.match(/\b(M1|A1|B1|P1|cao|oe\b|ft\b|follow through|additional guidance|mark scheme)\b/gi) ?? []).length;
  return hits >= 4;
}

export function classifyPair(
  a: { name: string; text: string },
  b: { name: string; text: string },
): { paperFirst: boolean; reason: string } {
  const aMs = looksLikeMarkScheme(a.name, a.text);
  const bMs = looksLikeMarkScheme(b.name, b.text);
  if (aMs && !bMs) return { paperFirst: false, reason: `${a.name} reads as a mark scheme.` };
  if (bMs && !aMs) return { paperFirst: true, reason: `${b.name} reads as a mark scheme.` };
  return { paperFirst: true, reason: "First file treated as your paper, second as the mark scheme. Swap if that is wrong." };
}

async function loadPdfjs() {
  const pdfjs = await import("pdfjs-dist");
  const worker = await import("pdfjs-dist/build/pdf.worker.min.mjs?url");
  pdfjs.GlobalWorkerOptions.workerSrc = worker.default;
  return pdfjs;
}

export async function extractPdfText(file: File, maxPages = MAX_PAGES): Promise<string> {
  const pdfjs = await loadPdfjs();
  const data = new Uint8Array(await file.arrayBuffer());
  const doc = await pdfjs.getDocument({ data, isEvalSupported: false }).promise;
  const n = Math.min(doc.numPages, maxPages);
  const parts: string[] = [];
  for (let i = 1; i <= n; i++) {
    const page = await doc.getPage(i);
    const content = await page.getTextContent();
    const line = content.items
      .map((item) => ("str" in item ? String(item.str) : ""))
      .join(" ")
      .replace(/\s+/g, " ")
      .trim();
    if (line) parts.push(line);
  }
  return parts.join("\n");
}

function canvasToJpeg(canvas: HTMLCanvasElement, quality: number): string {
  const url = canvas.toDataURL("image/jpeg", quality);
  return url.split(",")[1] ?? "";
}

async function bitmapToJpeg(source: CanvasImageSource, w: number, h: number): Promise<PageImage> {
  const scale = Math.min(1, MAX_EDGE / Math.max(w, h));
  const width = Math.max(1, Math.round(w * scale));
  const height = Math.max(1, Math.round(h * scale));
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Could not draw that page.");
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, width, height);
  ctx.drawImage(source, 0, 0, width, height);
  let quality = 0.72;
  let base64 = canvasToJpeg(canvas, quality);
  while (base64.length > TARGET_B64 && quality > 0.42) {
    quality -= 0.1;
    base64 = canvasToJpeg(canvas, quality);
  }
  if (!base64) throw new Error("Could not encode that page.");
  return { mime: "image/jpeg", base64, page: 0, width, height };
}

export async function renderPdfPages(file: File, maxPages = MAX_PAGES): Promise<PageImage[]> {
  const pdfjs = await loadPdfjs();
  const data = new Uint8Array(await file.arrayBuffer());
  const doc = await pdfjs.getDocument({ data, isEvalSupported: false }).promise;
  const n = Math.min(doc.numPages, maxPages);
  const pages: PageImage[] = [];
  for (let i = 1; i <= n; i++) {
    const page = await doc.getPage(i);
    const base = page.getViewport({ scale: 1 });
    const scale = Math.min(1.6, MAX_EDGE / Math.max(base.width, base.height));
    const viewport = page.getViewport({ scale });
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.floor(viewport.width));
    canvas.height = Math.max(1, Math.floor(viewport.height));
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("Could not render a PDF page.");
    await page.render({ canvasContext: ctx, viewport }).promise;
    const img = await bitmapToJpeg(canvas, canvas.width, canvas.height);
    pages.push({ ...img, page: i });
  }
  return pages;
}

export async function imageFileToPage(file: File, page: number): Promise<PageImage> {
  const bitmap = await createImageBitmap(file);
  const img = await bitmapToJpeg(bitmap, bitmap.width, bitmap.height);
  bitmap.close();
  return { ...img, page };
}

export async function filesToPages(files: File[], maxPages = MAX_PAGES): Promise<{
  images: PageImage[];
  text: string;
  truncated: boolean;
  pageCount: number;
}> {
  const images: PageImage[] = [];
  const texts: string[] = [];
  let pageCount = 0;
  let truncated = false;
  for (const file of files) {
    const pdf = file.type === "application/pdf" || /\.pdf$/i.test(file.name);
    if (pdf) {
      const text = await extractPdfText(file, maxPages);
      if (text) texts.push(text);
      const rendered = await renderPdfPages(file, Math.max(1, maxPages - images.length));
      pageCount += rendered.length;
      if (images.length + rendered.length >= maxPages) truncated = true;
      images.push(...rendered.slice(0, maxPages - images.length));
    } else if (file.type.startsWith("image/")) {
      pageCount += 1;
      if (images.length >= maxPages) {
        truncated = true;
        continue;
      }
      images.push(await imageFileToPage(file, images.length + 1));
    }
    if (images.length >= maxPages) truncated = true;
  }
  return { images, text: texts.join("\n\n"), truncated, pageCount: Math.max(pageCount, images.length) };
}

export function isPdfOrImage(file: File): boolean {
  return file.type === "application/pdf" || file.type.startsWith("image/") || /\.pdf$/i.test(file.name);
}
