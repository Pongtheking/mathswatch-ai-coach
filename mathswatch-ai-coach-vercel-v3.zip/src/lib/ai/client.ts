import { z } from "zod";

// Gemini Flash keeps the tutoring and document-analysis flows low-cost while
// retaining multimodal input support for question and paper images.
const MODEL = "gemini-3.8-flash";
const GEMINI_URL = `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`;

export type ChatContent =
  | string
  | Array<
      | { type: "text"; text: string }
      | { type: "image_url"; image_url: { url: string } }
    >;

export type ChatMessage = {
  role: "system" | "user" | "assistant";
  content: ChatContent;
};

export function aiAvailable(): boolean {
  return Boolean(process.env.GEMINI_API_KEY);
}

type GeminiPart =
  | { text: string }
  | { inlineData: { mimeType: string; data: string } };

function partsFromContent(content: ChatContent): GeminiPart[] {
  if (typeof content === "string") return [{ text: content }];
  return content.map((part) => {
    if (part.type === "text") return { text: part.text };
    const match = /^data:([^;]+);base64,(.*)$/s.exec(part.image_url.url);
    if (!match) return { text: "" };
    return { inlineData: { mimeType: match[1], data: match[2] } };
  });
}

function toGeminiRequest(messages: ChatMessage[]) {
  const systemParts: GeminiPart[] = [];
  const contents: { role: "user" | "model"; parts: GeminiPart[] }[] = [];
  for (const m of messages) {
    if (m.role === "system") {
      systemParts.push(...partsFromContent(m.content));
      continue;
    }
    contents.push({
      role: m.role === "assistant" ? "model" : "user",
      parts: partsFromContent(m.content),
    });
  }
  return {
    contents,
    systemInstruction: systemParts.length ? { parts: systemParts } : undefined,
  };
}

async function callGemini(
  messages: ChatMessage[],
  opts?: { maxTokens?: number; temperature?: number; json?: boolean },
): Promise<{ ok: true; text: string } | { ok: false; error: string }> {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return { ok: false, error: "AI is not available in this environment." };
  const { contents, systemInstruction } = toGeminiRequest(messages);
  const body = {
    contents,
    systemInstruction,
    generationConfig: {
      temperature: opts?.temperature ?? 0.2,
      maxOutputTokens: opts?.maxTokens ?? 1800,
      ...(opts?.json ? { responseMimeType: "application/json" } : {}),
    },
  };
  try {
    const res = await fetch(`${GEMINI_URL}?key=${apiKey}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    if (!res.ok) {
      const text = await res.text().catch(() => "");
      if (res.status === 429) {
        return {
          ok: false,
          error:
            "Free Gemini quota hit for the moment — wait a minute (or a day for the daily cap) and try again.",
        };
      }
      return { ok: false, error: `AI request failed (${res.status}). ${text.slice(0, 180)}` };
    }
    const json = (await res.json()) as {
      candidates?: { content?: { parts?: { text?: string }[] } }[];
    };
    const content =
      json.candidates?.[0]?.content?.parts?.map((p) => p.text ?? "").join("") ?? "";
    return { ok: true, text: content };
  } catch (err) {
    return {
      ok: false,
      error: err instanceof Error ? err.message : "Network error talking to AI.",
    };
  }
}

export async function chatJson<T>(
  schema: z.ZodType<T>,
  messages: ChatMessage[],
  opts?: { maxTokens?: number; temperature?: number },
): Promise<{ ok: true; data: T } | { ok: false; error: string }> {
  const result = await callGemini(messages, { ...opts, json: true });
  if (!result.ok) return result;
  const parsed = extractJson(result.text);
  const data = schema.safeParse(parsed);
  if (!data.success) {
    return { ok: false, error: "The AI response could not be validated. Please retry." };
  }
  return { ok: true, data: data.data };
}

export async function chatText(
  messages: ChatMessage[],
  opts?: { maxTokens?: number },
): Promise<{ ok: true; text: string } | { ok: false; error: string }> {
  const result = await callGemini(messages, {
    maxTokens: opts?.maxTokens ?? 900,
    temperature: 0.35,
  });
  if (!result.ok) return result;
  return { ok: true, text: result.text };
}

function extractJson(raw: string): unknown {
  const trimmed = raw.trim();
  try {
    return JSON.parse(trimmed);
  } catch {
    const start = trimmed.indexOf("{");
    const end = trimmed.lastIndexOf("}");
    if (start >= 0 && end > start) {
      try {
        return JSON.parse(trimmed.slice(start, end + 1));
      } catch {
        return null;
      }
    }
    return null;
  }
}

export function dataUrlFromBase64(mime: string, b64: string): string {
  if (b64.startsWith("data:")) return b64;
  return `data:${mime};base64,${b64}`;
}

export function imageParts(
  images: Array<{ mime: string; base64: string }>,
): Array<{ type: "image_url"; image_url: { url: string } }> {
  return images.map((img) => ({
    type: "image_url" as const,
    image_url: { url: dataUrlFromBase64(img.mime, img.base64) },
  }));
}
