/** Turns low-level AI failures into concise guidance safe to show to students. */
export function friendlyAiError(raw: string | undefined | null): string {
  const message = (raw ?? "").trim();
  if (!message) return "Something went wrong. Please retry.";
  if (/429|quota/i.test(message)) {
    return "The AI service is busy right now. Wait a minute and try again.";
  }
  if (/not available/i.test(message)) return "AI is not available in this environment right now.";
  if (/validat/i.test(message)) return "The AI response could not be read cleanly. Retry with a clearer photo or PDF.";
  if (/network|failed to fetch|timeout/i.test(message)) return "Network hiccup talking to the coach. Check your connection and retry.";
  return message;
}
